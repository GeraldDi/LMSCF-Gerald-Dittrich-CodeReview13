<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;


use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Entity\Events;//hier die Event classe hinzufügen


class MainController extends Controller
{
  /**
    * @Route("/", name="home_page")
    */
   public function showAction()
   {
              $todos = $this->getDoctrine()->getRepository('App:Events')->findAll(); //die Entity hat bei mir den Namen Events
     
       return $this->render('main/index.html.twig', array('todos'=>$todos));
   }


    /**
    * @Route("/create", name="create_page")
    */
   public function createAction(Request $request)
   {
       // Here we create an object from the class that we made
       $todo = new Events;
/* Here we will build a form using createFormBuilder and inside this function we will put our object and then we write add then we select the input type then an array to add an attribute that we want in our input field */
       $form = $this->createFormBuilder($todo)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
         ->add('date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
       ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       
   ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   ->add('phonenumber', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   ->add('type', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))


   ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
       ->getForm();
       $form->handleRequest($request);
       

       /* Here we have an if statement, if we click submit and if  the form is valid we will take the values from the form and we will save them in the new variables */
       if($form->isSubmitted() && $form->isValid()){
           //fetching data

           // taking the data from the inputs by the name of the inputs then getData() function
       	   $name = $form['name']->getData();
           $date = $form['date']->getData();
           $description = $form['description']->getData();
           $image = $form['image']->getData();
           $capacity = $form['capacity']->getData();
           $email = $form['email']->getData();
           $phonenumber = $form['phonenumber']->getData();
           $address = $form['address']->getData();
           $url = $form['url']->getData();
           $type = $form['type']->getData();
           
           // Here we will get the current date
           $now = new\DateTime('now');

/* these functions we bring from our entities, every column have a set function and we put the value that we get from the form */
           $todo->setName($name);
           $todo->setDate($date);
           $todo->setDescription($description);
           $todo->setImage($image);
           $todo->setCapacity($capacity);
           $todo->setEmail($email);
           $todo->setPhonenumber($phonenumber);
           $todo->setAddress($address);
           $todo->setUrl($url);
           $todo->setType($type);



           $em = $this->getDoctrine()->getManager();
           $em->persist($todo);
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Added'
                   );
           return $this->redirectToRoute('home_page');
       }
/* now to make the form we will add this line form->createView() and now you can see the form in create.html.twig file  */
       return $this->render('main/create.html.twig', array('form' => $form->createView()));
   }



	   /**
	    * @Route("/edit/{id}", name="todo_edit")
	    */
	   public function editAction( $id, Request $request){
		/* Here we have a variable todo and it will save the result of this search and it will be one result because we search based on a specific id */
		   $todo = $this->getDoctrine()->getRepository('App:Events')->find($id);
		$now = new\DateTime('now');
		/* Now we will use set functions and inside this set functions we will bring the value that is already exist using get function for example we have setName() and inside it we will bring the current value and use it again */
	           $todo->setName($todo->getName());
	           $todo->setDate($todo->getDate());
	           $todo->setDescription($todo->getDescription());
	           $todo->setCapacity($todo->getCapacity());
	           $todo->setEmail($todo->getEmail());
	           $todo->setPhonenumber($todo->getPhonenumber());
	           $todo->setAddress($todo->getAddress());
	           $todo->setUrl($todo->getUrl());
	           $todo->setType($todo->getType());

	           // $todo->setCreateDate($now);
		/* Now when you type createFormBuilder and you will put the variable todo the form will be filled of the data that you already set it */
	   //     $form = $this->createFormBuilder($todo)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
	   //     ->add('category', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
	   //     ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
	   //     ->add('priority', ChoiceType::class, array('choices'=>array('Low'=>'Low', 'Normal'=>'Normal', 'High'=>'High'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
	   // ->add('due_date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
	   // ->add('save', SubmitType::class, array('label'=> 'Update Todo', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-botton:15px')))
	   //     ->getForm();

		$form = $this->createFormBuilder($todo)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
         ->add('date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
       ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       
   ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   ->add('phonenumber', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   ->add('type', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))


   ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
       ->getForm();
      

	       $form->handleRequest($request);
	       if($form->isSubmitted() && $form->isValid()){
	           //fetching data
	           $name = $form['name']->getData();
	           $date = $form['date']->getData();
	           $description = $form['description']->getData();
	           $capacity = $form['capacity']->getData();

	           $email = $form['email']->getData();
	           $phonenumber = $form['phonenumber']->getData();
	           $address = $form['address']->getData();
	           $url = $form['url']->getData();
	           $type = $form['type']->getData();
	           
	           $now = new\DateTime('now');
	           $em = $this->getDoctrine()->getManager();
	           $todo = $em->getRepository('App:Events')->find($id);
	           $todo->setName($name);
	           $todo->setDate($date);
	           $todo->setDescription($description);
	           $todo->setCapacity($capacity);
	           $todo->setEmail($email);
	           $todo->setPhonenumber($phonenumber);
	           $todo->setAddress($address);
	           $todo->setUrl($url);
	           $todo->setType($type);
	       
	           $em->flush();
	           $this->addFlash(
	                   'notice',
	                   'Events Updated'
	                   );
	           return $this->redirectToRoute('home_page');
	       }
	       return $this->render('main/edit.html.twig', array('todo' => $todo, 'form' => $form->createView()));
	   }



  
/**
    * @Route("/details/{id}", name="details_page")
    */
   public function detailsAction($id)
   {
       $todo = $this->getDoctrine()->getRepository('App:Events')->find($id);
       return $this->render('main/details.html.twig', array('todo' => $todo));
   }

       /**
    * @Route("/delete/{id}", name="todo_delete")
    */
   public function deleteAction($id){
                $em = $this->getDoctrine()->getManager();
           $todo = $em->getRepository('App:Events')->find($id);
           $em->remove($todo);
            $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Removed'
                   );
            return $this->redirectToRoute('home_page');
   }
}
?>